/**
 * Selects the alphabet that's used for the morse code mappings
 * from multiple possible sets.
 */

#include "alphabet1.hpp"
// #include "alphabet_rand1.hpp"
// #include "alphabet_rand2.hpp"
// #include "alphabet_4_symbol.hpp"
